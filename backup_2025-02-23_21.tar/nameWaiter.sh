#!/bin/bash
read NAME
echo "Hello, $NAME"
