#!/bin/bash
VAR="I'm a new variable"
echo $VAR
read VAR
echo "$VAR"
